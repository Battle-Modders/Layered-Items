var LayeredItems = {
	ID = "mod_layered_items"
}

// $.fn.assignPaperdollItemOverlayImage is the original ish

LayeredItems.assignPaperdollLayeredImage = function(_isBlocked)
{
	var layersLayer = this.find('.image-layer > .layered-item-layer:first');
	layersLayer.empty();
	var itemData = this.data('item');
	if (itemData.LayeredItems_Icons == undefined) return;

	var itemData = this.data('item');
	itemData.LayeredItems_Icons.forEach(function (_layerPath)
	{
		if (_layerPath == '')
		{
			console.error("Passed image path with no value to assignPaperdollLayeredImage");
			return;
		}
		var layerImage = $('<img/>');
		layerImage.attr('src', Path.ITEMS + _layerPath);

		if (itemData.isImageSmall === true) layerImage.addClass('is-small');
		if (_isBlocked === true) layerImage.addClass('is-blocked');
		layersLayer.append(layerImage);
	});
}
