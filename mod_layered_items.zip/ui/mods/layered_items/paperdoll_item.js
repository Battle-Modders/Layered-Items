LayeredItems.createPaperdollItem = $.fn.createPaperdollItem;
$.fn.createPaperdollItem = function(_isBig, _backgroundImage, _classes)
{
	var result = LayeredItems.createPaperdollItem.call(this, _isBig, _backgroundImage, _classes);
	result.find('.image-layer:first').append($('<div class="layered-item-layer"/>'));
	return result;
}
